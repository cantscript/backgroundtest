#!/bin/bash

LOGGED_IN_USER=$(stat -f "%Su" /dev/console)

if [[ -z "$LOGGED_IN_USER" || "$LOGGED_IN_USER" == "root" ]]; then
	exit 0
fi

LOGGED_IN_UID=$(id -u "$LOGGED_IN_USER")

/bin/launchctl asuser "$LOGGED_IN_UID" /usr/bin/sudo -u "$LOGGED_IN_USER" /usr/bin/osascript -e 'display dialog "This is a test" buttons {"OK"} default button "OK"'
